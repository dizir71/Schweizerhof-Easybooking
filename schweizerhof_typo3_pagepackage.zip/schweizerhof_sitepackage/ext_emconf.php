<?php

$EM_CONF[$_EXTKEY] = [
    'title' => 'Schweizerhof Sitepackage',
    'description' => 'Design und Layout für das Gästehaus Schweizerhof am Traunsee',
    'category' => 'templates',
    'author' => 'ChatGPT',
    'author_email' => 'kontakt@schweizerhof.at',
    'state' => 'stable',
    'clearCacheOnLoad' => 1,
    'version' => '1.0.0',
    'constraints' => [
        'depends' => [
            'typo3' => '10.4.0-12.4.99'
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];
